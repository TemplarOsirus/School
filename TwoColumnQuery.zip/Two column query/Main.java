import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Main extends JFrame {

	private MyVis ana;
	private Connection conn;
	

	public Main() {
		setupDB();
		runQuery("SELECT COUNT(*), major FROM cis GROUP BY major");
		//ana = new MyVis();
		setContentPane(ana);
		setSize(1000,800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("My First CS 490R Program");
		setJMenuBar(setupMenu());
		
		setVisible(true);
	}

	private void runQuery(String sql) {
		double roundOff;
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			List<Double> nums = new ArrayList<>();
			List<String> labels = new ArrayList<>();
			List<String> countries = new ArrayList<>();
			while (rs.next()) {
				double dexter = rs.getDouble(1);
				String yijie = rs.getString(2);
				roundOff = Math.round(dexter * 100.00) / 100.00;
				//System.out.println("this is roundoff " + roundOff);
				nums.add(roundOff);
				labels.add(yijie);
				System.out.println("There are " + dexter + " students in major " + yijie);
				
			}
			for(int i=0; i<nums.size(); i++) {
				System.out.println(nums.get(i));
			}
			
			rs.close();
			s.close();
			if(ana==null) {
				ana=new MyVis(nums,labels);
			}else {
				ana.setData(nums, labels);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void setupDB() {
		try {
			conn = DriverManager.getConnection("jdbc:derby:cs490R");
//			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public JMenuBar setupMenu() {
		var menu = new JMenuBar();
		var vika = new JMenu("Chart Type");
		var dexter = new JMenu("QueryOne");
		var nate = new JMenuItem("Average GPA");
		var yoshiki = new JMenuItem("First Query");
		var yijie = new JMenuItem("Home Areas");
		var draper = new JMenuItem("Credits Attempted");
		var slade = new JMenuItem("Credits Passed");
		var lineChart = new JMenuItem("Line Chart");
		var barChart = new JMenuItem("Bar Chart");
		var gpa =new JMenuItem("GPA");
		dexter.add(yoshiki);
		dexter.add(yijie);
		dexter.add(nate);
		dexter.add(draper);
		dexter.add(slade);
		dexter.add(gpa);
		vika.add(lineChart);
		vika.add(barChart);
		//vika.add(nate);

		yoshiki.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					
				runQuery("SELECT COUNT(*), major FROM cis GROUP BY major");
			}

		});
		yijie.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				runQuery("SELECT COUNT(*), home FROM cis GROUP BY home");
			}

		});
		nate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				runQuery("SELECT avg(gpa), major FROM cis GROUP BY major");
			}

		});
		draper.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				runQuery("SELECT avg(credits_attempted), yeer FROM cis GROUP BY yeer");
			}

		});
		slade.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				runQuery("SELECT avg(credits_passed), yeer FROM cis GROUP BY yeer");
			}

		});
		gpa.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				runQuery("SELECT count(*), gpa_range from cis group by gpa_range");
			}

		});
		lineChart.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ana.changeTable(false);
				

			}

		});
		barChart.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				ana.changeTable(true);
				

			}

		});

		//nate.addActionListener(e -> ana.changeMessage("Nate was here!"));
		menu.add(vika);
		menu.add(dexter);
		
		return menu;
	}

	public static void main(String[] args) {
		new Main();
	}

}
