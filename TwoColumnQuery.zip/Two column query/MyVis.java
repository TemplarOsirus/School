import java.awt.Color;
import java.awt.Graphics;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JPanel;

public class MyVis extends JPanel {

	private String message;
	private List<Double> nums;
	private List<String> labels;
	private int relative;
	private List<Double> ratios;
	private DecimalFormat df1;
	private boolean barGraph;

	public MyVis(List <Double> nums,List<String> labels) {
		super();
		message = "CS490R is my favorite class!";
		this.nums= nums;
		this.labels = labels;
		relative = nums.size();
		ratios = new ArrayList<>();
		df1= new DecimalFormat("#.##");
		barGraph= true;
	}

	@Override
	public void paintComponent(Graphics g) {
		//g.drawString(message, 10, 10);
		//		for (int i=0; i<nums.size(); i++) {
		//			g.drawString(""+nums.get(i) + ", " + labels.get(i), 10, i*20+10);
		//		}
		double maxV = Collections.max(nums);


		double step1 = (maxV+30)*.9;
		double step2 = (maxV+30)*.6;
		double step3 = (maxV+30)*.3;



		for(int i = 0; i < nums.size(); i++) {

			ratios.add(nums.get(i)/ ((maxV)+30));
			//System.out.println("The numbers in " +nums.get(i));
			System.out.println(ratios.get(i));
		}


		//int n = relative.size();
		int spacing = (getWidth() / (relative+1)-50);
		int y = spacing;
		int barLength;
		int barSpace=50;
		//		Collections.sort(nums);
		//		Collections.reverse(nums);
		for (int i=0; i<relative; i++) {
			// to get the barlength we typecast it into and int I take the width divided by the size of the nums array 
			barLength = (int)(getWidth()/relative)-75;
			//g.drawLine(0, y, barLength, y);
			// this is where the data is made
			g.setColor(Color.green);
			// the following is where i can change it from a bar graph to a line graph
			if(barGraph== true ) {
				g.setColor(Color.black);
				// these are the numbers over the top of the bars
				g.drawString((String)(nums.get(i)).toString(),(i*barLength + barSpace)+50 ,(int)(getHeight()*(1-ratios.get(i).doubleValue())-50));
				g.setColor(Color.green);
				//this is where the rectangles are made
				g.fillRect(i*barLength + barSpace ,(int)(getHeight()*(1-ratios.get(i).doubleValue())-50),barLength,(int)(getHeight()*ratios.get(i).doubleValue()));
				g.setColor(Color.black);
				g.drawRect(i*barLength + barSpace ,(int)(getHeight()*(1-ratios.get(i).doubleValue())-50),barLength,(int)(getHeight()*ratios.get(i).doubleValue()));
				barSpace +=20;

			}else {
				g.setColor(Color.blue);
				if(i< relative -1) {

					g.drawLine((int)(i*barLength + barSpace)+50 ,(int)(getHeight()*(1-ratios.get(i).doubleValue())-50),(int)((i+1)*barLength + barSpace)+50, (int)(getHeight()*(1-ratios.get(i+1).doubleValue())-50));
					//i++;
				}
				g.fillOval(((int)(i*barLength + barSpace)+50)-20 ,((int)(getHeight()*(1-ratios.get(i).doubleValue())-50)-15), 35, 35);
				g.setColor(Color.BLACK);
				g.drawOval(((int)(i*barLength + barSpace)+50)-20 ,((int)(getHeight()*(1-ratios.get(i).doubleValue())-50)-15), 35, 35);

			}

			//g.drawRect(0, y, barLength, y);
			// this is where the labels are made
			g.setColor(Color.black);

			//var john = nums.get(i);
			//var labelNums = String.format("{0:0.##}",john);


			//g.drawString((String)(labelNums), 0, y);
			// here i add the number 0 to the bottom
			g.drawString("0", 0+5,(getHeight()-50) );
			// this the number on the left changed to a string and shortens the decimal places
			//g.drawString((String)(nums.get(i)).toString(), 0, (int)(getHeight()*(1-ratios.get(i).doubleValue())-50));
			// these are the labels along the bottom
			g.drawString(labels.get(i),(i*barLength + barSpace),getHeight() -30 );
			y += spacing;
			//this is to separate the bars
			//barSpace +=20;
			//barSpace =50;

			//this is where the x-axis and y-axis number are being made 
			g.drawLine((getWidth()*(int).1)+40, getHeight()-50, getWidth(), (getHeight()-50));
			//Horizontal
			g.drawLine((getWidth()*(int).1)+40, getHeight()-50, (getWidth()*(int).1)+40, (getHeight()* (int) .1));


			//g.drawString((String)(nums.get(i)).toString(), 0, (int)(getHeight()*(1-ratios.get(i).doubleValue())-50));
			//g.drawString(string, x, y);

			//g.drawString(" "+ maxV, 0,10);
			//these are the left side numbers Y axis
			g.setColor(Color.black);
			g.drawString( df1.format(step3), 0,(int)((getHeight()-50)*0.7));
			g.drawString(df1.format(step2), 0,(int)((getHeight()-50)*0.4));
			g.drawString(df1.format(step1), 0,(int)((getHeight()-50)*0.1));


		}
		ratios.clear();



		//labels.clear();
		//test to see what is in ratios
		//		for(int i=0; i<ratios.size(); i++) {
		//			System.out.println(ratios.get(i));
		//		}
	}

	public void changeMessage(String m) {
		message = m;
		repaint();
	}

	public void setData(List<Double> nums, List<String> labels) {
		this.nums = nums;
		this.labels = labels;
		double max = -1;
		for (var n : nums) {
			if (n > max) {
				max = n;
			}
		}
		//		for (int i=0; i<nums.size(); i++) {
		//			relative.add(nums.get(i) / max);
		//		}
		relative= nums.size();
		repaint();
	}
	public void changeTable(boolean b) {
		barGraph = b;
		repaint();
	}

}
