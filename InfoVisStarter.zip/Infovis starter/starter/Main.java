package starter;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.UIManager;


public class Main extends JFrame {
	
	private Vis mainPanel;
	private Connection conn;

	public Main() {
		
		JMenuBar mb = setupMenu();
		setJMenuBar(mb);
		
		mainPanel = new Vis();
		setContentPane(mainPanel);

		setSize(800,600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("You know where you are? Your in the Jungle Baby!");
		setVisible(true);
	}
	
	private JMenuBar setupMenu() {
		//instantiate menubar, menus, and menu options
		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenu fileMenu1 = new JMenu("Search");
		JMenu fileMenu2 = new JMenu("Students");
		
		JMenuItem item1 = new JMenuItem("Item 1");
		
		
		
		JMenu subMenu = new JMenu("Set the Box color");
		JMenu subMenu11 = new JMenu("Search by Gender");
		JMenu subMenu13 = new JMenu("Search by Time");
		JMenu subMenu12 = new JMenu("Search by Age");
		JMenu subMenu14 = new JMenu("firstQuery");
		
		
		
		
		JMenu subMenu2 = new JMenu("Background Color");
		JMenu subMenu1 = new JMenu("Set the Box size");
		
		JMenuItem red = new JMenuItem("Red");
		JMenuItem blue = new JMenuItem("Blue");
		JMenuItem male = new JMenuItem("Male");
		JMenuItem female = new JMenuItem("Female");
		JMenuItem lessThan25 = new JMenuItem("Less than 25");
		JMenuItem between = new JMenuItem("Between 25 and 39");
		JMenuItem more = new JMenuItem("Greater than or equal to 40");
		JMenuItem lessThan4 = new JMenuItem("Less than 4 hours");
		JMenuItem between1 = new JMenuItem("Between 4 and 5");
		JMenuItem more1 = new JMenuItem("More than 5 hours");
		JMenuItem query1 = new JMenuItem("test query");
		
		JMenuItem green = new JMenuItem("Green");
		JMenuItem orange = new JMenuItem("Orange");
		
		JMenuItem smaller = new JMenuItem("Smaller");
		JMenuItem larger = new JMenuItem("Larger");
		
		//JMenuItem color = new JMenuItem("Color");
		JMenuItem size = new JMenuItem("Size");
		JMenuItem other = new JMenuItem("Other");
		JMenu backGround = new JMenu("Set the Background Color");
		
		//setup action listeners
		query1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
					
				runQuery("SELECT COUNT(*), major FROM cis GROUP BY major");
			}

		});
		item1.addActionListener(e -> mainPanel.changeMessage("Just clicked menu item 1"));		
		// this is for the color of the box
		red.addActionListener(e -> mainPanel.changeColor(Color.red));
		blue.addActionListener(e -> mainPanel.changeColor(Color.blue));
		// this is for the color of the background
		green.addActionListener(e -> mainPanel.changeBackground(Color.green));
		orange.addActionListener(e -> mainPanel.changeBackground(Color.orange));
		
		// this action changes the size of the square 
		smaller.addActionListener(e -> mainPanel.changeSize(50,50,50,50));
		larger.addActionListener(e -> mainPanel.changeSize(50,50,300,300));
		
		male.addActionListener(e -> mainPanel.changeGender("gender = 'M' AND ", " GENDER: Male"));
		female.addActionListener(e -> mainPanel.changeGender("gender = 'F' AND "," GENDER: Female"));
		
		lessThan25.addActionListener(e -> mainPanel.changeAge("age < 25 and ", "AGE: < 25"));
		between.addActionListener(e -> mainPanel.changeAge("age BETWEEN 25 AND 39 and ", " AGE: between 23 and 39"));
		more.addActionListener(e -> mainPanel.changeAge("age >= 40 and " , " AGE: >= 40"));
		
		lessThan4.addActionListener(e -> mainPanel.changeTime("hours < 4", " TIME: < 4"));
		between1.addActionListener(e -> mainPanel.changeTime("hours BETWEEN 4 AND 5", " TIME: between 4 and 5"));
		more1.addActionListener(e -> mainPanel.changeTime("hours > 5", " TIME: > 5"));
		
		
		
		//color.addActionListener(e -> mainPanel.changeMessage("You pressed color option"));
		size.addActionListener(e -> mainPanel.changeMessage("You pressed size option"));
		other.addActionListener(e -> mainPanel.changeMessage("You pressed other option"));
		
		
		//now hook them all together
		subMenu13.add(lessThan4);
		subMenu13.add(between1);
		subMenu13.add(more1);
		subMenu12.add(lessThan25);
		subMenu12.add(between);
		subMenu12.add(more);
		subMenu11.add(male);
		subMenu11.add(female);
		subMenu1.add(smaller);
		subMenu1.add(larger);
		subMenu.add(red);
		subMenu.add(blue);
		subMenu14.add(query1);

		//fileMenu.add(subMenu);
		fileMenu1.add(subMenu11);
		fileMenu1.add(subMenu13);
		fileMenu1.add(subMenu12);
		fileMenu.add(subMenu1);
		fileMenu.add(backGround);
		fileMenu2.add(subMenu14);
		subMenu2.add(green);
		subMenu2.add(orange);
		backGround.add(green);
		backGround.add(orange);
		
		menuBar.add(fileMenu);
		menuBar.add(fileMenu1);
		menuBar.add(fileMenu2);
		
		
		
		return menuBar;
	}
	private void runQuery(String sql) {
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			List<Double> nums = new ArrayList<>();
			List<String> labels = new ArrayList<>();
			while (rs.next()) {
				double dexter = rs.getDouble(1);
				String yijie = rs.getString(2);
				nums.add(dexter);
				labels.add(yijie);
				System.out.println("There are " + dexter + " students in major " + yijie);
			}
			rs.close();
			s.close();
			mainPanel.setData(nums, labels);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void setupDB() {
		try {
			conn = DriverManager.getConnection("jdbc:derby:cs490R");
//			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public static void main(String[] args) {

		//this makes the GUI adopt the look-n-feel of the windowing system (Windows/X11/Mac)
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) { }

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Main();
			}
		});
	}
}
