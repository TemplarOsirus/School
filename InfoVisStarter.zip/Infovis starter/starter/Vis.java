package starter;
import java.awt.Color;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class Vis extends JPanel {
	private String message;
	private Color boxColor;
	private Color backGround;
	private int x;
	private int y;
	private int w;
	private int h;

	private ImageIcon[] pictures;
	private int currentFrame;
	private String first,gender,age,time;
	private String defaultGender,defaultAge,defaultTime;
	// variable for bar and charts
	private List<Double> nums;
	private List<String> labels;
	private List<Double> relative;



	public Vis() {

		super();
		// creating array lists to store the int and labels 
		nums = new ArrayList<>();
		labels = new ArrayList<>();
		relative = new ArrayList<>();
		// below is my default account this contains the sql statement
		first = "SELECT COUNT(*) FROM marathon where ";
		gender = "gender = 'M' AND ";
		age = "age < 25 and ";
		time = "hours < 4";
		defaultGender = " GENDER: Male";
		defaultAge = " AGE: < 25 years";
		defaultTime = " TIME: < 4 hours";
		// here is my message to the people
		message ="Welcome to the Jungle it gets worse here everyday";
		boxColor = Color.yellow;
		backGround = Color.magenta;
		x=100;
		y=300;
		w=400;
		h=50;
		pictures = new ImageIcon[3];
		currentFrame = 0;
		pictures[0] = new ImageIcon("mario1.gif");
		pictures[1] = new ImageIcon("mario2.gif");	
		pictures[2] = new ImageIcon("mario3.gif");
		// this is my timer that i have not started right now
		Timer t = new Timer(80, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent a) {
				currentFrame= (currentFrame +1) % pictures.length;
				repaint();
			}
		});
		t.start();




	}

	@Override
	public void paintComponent(Graphics g1) {
		Graphics2D g = (Graphics2D)g1;

		//draw blank background
		g.setColor(backGround);
		g.fillRect(0, 0, getWidth(), getHeight());

		//render visualization
		g.setColor(Color.BLACK);
		// this is where i draw the text lines for the results
		g.drawString(runQuery(first,gender,age,time), 100, 400);
		g.drawString(defaultGender, 100, 415);
		g.drawString(defaultTime, 100, 430);
		g.drawString(defaultAge, 100, 445);
		g.setColor(boxColor);
		g.fillRect(x,y,w,h);
		pictures[currentFrame].paintIcon(this,g,200,50);
		
		int n = relative.size();
		int spacing = getHeight() / (n+1);
		int y = spacing;
		for (int i=0; i<n; i++) {
			int barLength = (int)(getWidth() * relative.get(i));
			g.drawLine(0, y, barLength, y);
			g.drawString(labels.get(i), 0, y);
			y += spacing;
		}

	}

	// the following methods are names pretty well to what they are doing
	public void changeMessage(String m) {
		message = m;
		repaint();
	}
	public void changeColor(Color c) {
		boxColor = c;
		repaint();

	}
	public void changeBackground(Color c) {
		backGround = c;
		repaint();
	}

	public void changeSize(int x1, int y1, int w1, int h1) {
		x=x1;
		y=y1;
		w=w1;
		h=h1;
		repaint();

	}
	public void changeAge(String a, String b) {
		age = a;
		defaultAge = b;
		repaint();
	}
	public void changeGender(String g, String c) {
		gender = g;
		defaultGender = c;
		repaint();
	}
	public void changeTime(String t, String d) {
		time = t;
		defaultTime = d;
		repaint();

	}
	public void setData(List<Double> nums, List<String> labels) {
		this.nums = nums;
		this.labels = labels;
		double max = -1;
		for (var n : nums) {
			if (n > max) {
				max = n;
			}
		}
		for (int i=0; i<nums.size(); i++) {
			relative.add(nums.get(i) / max);
		}
		repaint();
	}
	// created a method here together parameter to run the query
	public String runQuery(String f,String g,String a, String t) {
		gender=g;
		age=a;
		time=t;
		first =f;
		String test = f+g+a+t;
		int count=0;



		try {
			Connection conn = DriverManager.getConnection("jdbc:derby:cs490R");
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(test);
			rs.next();
			count = rs.getInt(1);



			//System.out.println("There are " + count + " rows in my table.");
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count + " athletes have the attributes:";

	}

}
